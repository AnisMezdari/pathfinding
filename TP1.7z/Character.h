#pragma once
class Character
{
public:

	float positionX;
	float positionY;

	Character(float positionX, float positionY);
};

