#include "Character.h"



Character::Character(float positionX, float positionY)
{
	this->positionX = positionX;
	this->positionY = positionY;
}



